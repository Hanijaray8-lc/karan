import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
  FiBarChart2,
  FiFileText,
  FiDollarSign,
  FiMenu,
  FiX,
  FiLogOut,
  FiUser
} from 'react-icons/fi';

const API_URL = process.env.REACT_APP_API_URL || 'https://karanfinance.com/api';

// Remember when the backend status was last verified, so navigating between pages
// (which re-mounts this navbar) doesn't hit the API / redirect every single time.
let lastStatusCheckAt = 0;
const STATUS_CHECK_INTERVAL_MS = 60 * 1000;

// Paths that should run the RefreshButton refresh when clicked
const RELOAD_PATHS = ['/DailyDues'];

const readAgentData = () => {
  const fallback = { name: 'Staff', role: 'Loan Officer', profilePhoto: null };
  try {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      return {
        name: user.name || user.username || 'Staff',
        role: user.role ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : 'Loan Officer',
        profilePhoto: user.profilePhoto || null
      };
    }
  } catch (e) {
    // ignore
  }
  return fallback;
};

const navItems = [
  { path: '/AgentDashboard', label: 'Dashboard', icon: FiBarChart2 },
  { path: '/DailyDues', label: 'Weekly Dues', icon: FiFileText },
  { path: '/ClientDetails', label: 'Client Profile', icon: FiUser },
  { path: '/ApaymentHistory', label: 'Payment', icon: FiDollarSign },
];

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);

  const location = useLocation();
  const navigate = useNavigate();

  // Lazy init => no "Staff" flash when navbar re-mounts
  const [agentData] = useState(readAgentData);

  // Run the auth / status check once per mount (NOT on every navigation)
  useEffect(() => {
    const token = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');

    if (!token) {
      navigate('/');
      return;
    }

    if (savedUser) {
      try {
        const user = JSON.parse(savedUser);
        if (user.status === 'Pending') {
          navigate('/');
          return;
        }
      } catch (e) {
        // ignore bad JSON
      }
    }

    // Skip the backend call if we verified very recently
    const now = Date.now();
    if (now - lastStatusCheckAt < STATUS_CHECK_INTERVAL_MS) return;
    lastStatusCheckAt = now;

    // Verify live status with backend
    axios.get(`${API_URL}/auth/check-status`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => {
      if (res.data && res.data.success) {
        if (res.data.status !== 'Active') {
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          lastStatusCheckAt = 0;
          navigate('/');
        }
      }
    }).catch(err => {
      if (err.response?.status === 401 || err.response?.status === 403) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        lastStatusCheckAt = 0;
        navigate('/');
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLogout = async () => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        await axios.post(`${API_URL}/auth/logout`, {}, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } catch (err) {
        console.error('Logout error:', err);
      }
    }
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    lastStatusCheckAt = 0;
    setIsLogoutModalOpen(false);
    navigate('/');
  };

  const getInitials = (name) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  };

  const initials = getInitials(agentData.name);

  const isActive = (path) => {
    return location.pathname === path;
  };

  // KEY FIX: clicking the link of the page you're already on must NOT navigate again
  // (a same-path navigation creates a new location key and re-mounts/refreshes the page)
  const handleNavClick = (e, path, closeMobile = false) => {
    // Weekly Dues: run the RefreshButton refresh (clear cache + reload).
    // Other links are untouched.
    if (RELOAD_PATHS.includes(path)) {
      e.preventDefault();
      if (closeMobile) setIsMobileMenuOpen(false);
      if (location.pathname !== path) {
        navigate(path);
      }
      // RefreshButton.js listens for this and runs its refresh function
      window.dispatchEvent(new Event('triggerAppRefresh'));
      return;
    }
    if (location.pathname === path) {
      e.preventDefault();
    }
    if (closeMobile) setIsMobileMenuOpen(false);
  };

  return (
    <>
      {/* Navbar - Full Width */}
      <nav
        className="sticky top-0 z-50 bg-[#16423C] backdrop-blur-sm border-b border-white/10 shadow-lg w-full"
        style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}
      >
        <div className="w-full px-6 h-16 flex items-center justify-between">

          {/* Brand Logo */}
          <Link
            to="/AgentDashboard"
            onClick={(e) => handleNavClick(e, '/AgentDashboard')}
            className="flex items-center gap-2 text-white font-bold text-xl min-w-fit"
          >
            <img src="/karanLogo.jpeg" alt="Karan Finance" className="h-11 w-11 rounded-full object-cover" />
            <span>Karan Finance</span>
          </Link>

          {/* Centered Navigation */}
          <div className="hidden lg:flex items-center justify-center flex-1 mx-10">
            <ul className="flex gap-4">
              {navItems.map((item) => (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    onClick={(e) => handleNavClick(e, item.path)}
                    className={`group relative flex items-center gap-3 px-5 py-2 rounded-lg transition-all duration-300 min-w-[145px] ${isActive(item.path)
                      ? 'bg-white/20 border border-white/30 text-white shadow-md'
                      : 'bg-white/5 text-white/85 border border-white/5 hover:bg-white/15'
                      }`}
                  >
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-lg ${isActive(item.path) ? 'bg-white/20' : 'bg-white/10'
                      }`}>
                      <item.icon />
                    </div>
                    <h6 className="font-semibold text-sm tracking-wide">{item.label}</h6>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* User Section - Profile Photo & Logout Icon */}
          <div className="hidden lg:flex items-center gap-6 min-w-fit pl-4 border-l border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-gradient-to-br from-[#6A9C89] to-[#16423C] flex items-center justify-center text-white font-bold text-xs border-2 border-white/20 shadow-xl">
                {agentData.profilePhoto ? (
                  <img src={agentData.profilePhoto} alt="profile" className="w-full h-full object-cover" />
                ) : (
                  initials
                )}
              </div>
              <div className="text-left">
                <h6 className="font-bold text-white text-sm leading-none">{agentData.name}</h6>
                <small className="text-[#C4DAD2] text-[11px] opacity-70">Agent Portal</small>
              </div>
            </div>

            <button
              onClick={() => setIsLogoutModalOpen(true)}
              className="p-2.5 rounded-xl bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white transition-all duration-300 border border-red-500/20 shadow-lg"
              title="Sign Out"
            >
              <FiLogOut size={18} />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden text-white text-2xl p-1">
            {isMobileMenuOpen ? <FiX /> : <FiMenu />}
          </button>
        </div>

        {/* Mobile Sidebar/Menu */}
        <div
          className={`lg:hidden absolute left-0 right-0 bg-[#16423C] border-b border-white/10 transition-all duration-300 ${isMobileMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-5 pointer-events-none'
            }`}
          style={{
            top: 'calc(4rem + env(safe-area-inset-top, 0px))',
            paddingBottom: 'env(safe-area-inset-bottom, 0px)'
          }}
        >
          <ul className="p-4 space-y-2">
            {navItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  onClick={(e) => handleNavClick(e, item.path, true)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg ${isActive(item.path) ? 'bg-white/20 text-white border border-white/20' : 'bg-white/5 text-white/85'
                    }`}
                >
                  <item.icon /> <span className="font-medium">{item.label}</span>
                </Link>
              </li>
            ))}
            <div className="pt-2 mt-2 border-t border-white/10 flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full overflow-hidden bg-[#6A9C89] flex items-center justify-center font-bold text-white shadow-lg">
                  {agentData.profilePhoto ? (
                    <img src={agentData.profilePhoto} alt="profile" className="w-full h-full object-cover" />
                  ) : (
                    initials
                  )}
                </div>
                <div>
                  <h6 className="text-white font-bold text-sm">{agentData.name}</h6>
                  <p className="text-[#C4DAD2] text-xs">Loan Officer</p>
                </div>
              </div>
              <button onClick={() => setIsLogoutModalOpen(true)} className="p-3 bg-red-500/20 text-red-400 rounded-xl">
                <FiLogOut size={20} />
              </button>
            </div>
          </ul>
        </div>
      </nav>

      {/* Logout Confirmation Modal */}
      {isLogoutModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-md px-4">
          <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center shadow-2xl animate-in zoom-in duration-200">
            <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-red-100">
              <FiLogOut className="text-2xl text-red-600" />
            </div>
            <h4 className="text-2xl font-bold text-gray-900">Sign Out</h4>
            <p className="text-gray-500 mt-2 mb-8">Are you sure you want to exit, <br /><span className="text-[#16423C] font-semibold">{agentData.name}</span>?</p>
            <div className="flex gap-3">
              <button onClick={() => setIsLogoutModalOpen(false)} className="flex-1 py-3.5 rounded-xl bg-gray-100 text-gray-700 font-bold hover:bg-gray-200 transition-colors">Cancel</button>
              <button onClick={handleLogout} className="flex-1 py-3.5 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 shadow-xl shadow-red-200 transition-colors">Logout</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Navbar;