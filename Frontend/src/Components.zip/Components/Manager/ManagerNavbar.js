import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ArrowRightOnRectangleIcon, Bars3Icon, XMarkIcon, BellIcon } from '@heroicons/react/24/outline';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'https://karanfinance.com/api';

const navItems = [
  { label: 'Dashboard', path: '/Manager/managerdashboard' },
  { label: 'Approvals', path: '/Manager/ManagerAproval', isApproval: true },
  { label: 'Add Client', path: '/Manager/MAddClient' },
  { label: 'Client Profile', path: '/Manager/MClientDetails' },
  { label: 'Transfer Clients', path: '/Manager/ClientManage' },
  { label: 'Weekly Dues', path: '/Manager/MDailyDues' },
  { label: 'Payment History', path: '/Manager/MpaymentHistory' },
  { label: 'Pending Clients', path: '/Manager/MPendingClients' },
  { label: 'Active / Inactive', path: '/Manager/Acive-Inactive' },
];

// Paths that should run the RefreshButton refresh when clicked (lowercase)
const RELOAD_PATHS = ['/manager/mdailydues'];

// ---- Helpers: keep state across navbar re-mounts (no flicker / no reset) ----
const PENDING_CACHE_KEY = 'mgrNavPending';

const readPendingCache = () => {
  try {
    const raw = sessionStorage.getItem(PENDING_CACHE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { count: parsed.count || 0, agents: parsed.agents || [] };
    }
  } catch (e) {
    // ignore
  }
  return { count: 0, agents: [] };
};

const writePendingCache = (count, agents) => {
  try {
    sessionStorage.setItem(PENDING_CACHE_KEY, JSON.stringify({ count, agents }));
  } catch (e) {
    // ignore
  }
};

const readManagerData = () => {
  const fallback = { name: 'Manager', role: 'Staff Manager', profilePhoto: null };
  try {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      return {
        name: user.name || user.username || 'Manager',
        role: user.role ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : 'Staff Manager',
        profilePhoto: user.profilePhoto || null
      };
    }
  } catch (err) {
    console.error('Error loading user data:', err);
  }
  return fallback;
};

const ManagerNavbar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);

  // Lazy init from localStorage / cache => no "flash" when navbar re-mounts
  const [managerData] = useState(readManagerData);
  const [pendingCount, setPendingCount] = useState(() => readPendingCache().count);
  const [pendingAgents, setPendingAgents] = useState(() => readPendingCache().agents);
  const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);
  const [newLoginAlert, setNewLoginAlert] = useState(null);

  const prevPendingCountRef = useRef(readPendingCache().count);
  const dropdownRef = useRef(null);
  const inFlightRef = useRef(false);
  const alertTimerRef = useRef(null);

  // Poll for pending agent approvals & login attempts
  useEffect(() => {
    let cancelled = false;

    const fetchPending = async () => {
      // Skip if tab is hidden or a request is already running
      if (document.hidden || inFlightRef.current) return;

      const token = localStorage.getItem('token');
      if (!token) return;

      inFlightRef.current = true;
      try {
        const res = await axios.get(`${API_URL}/agents/pending-approvals`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (cancelled) return;

        if (res.data && res.data.success) {
          const count = res.data.pendingCount || 0;
          const agents = res.data.pendingAgents || [];

          if (count > prevPendingCountRef.current && prevPendingCountRef.current !== 0) {
            const latest = agents[0];
            setNewLoginAlert(
              latest
                ? `${latest.name || latest.username} is requesting login approval!`
                : 'New agent login approval requested!'
            );
            if (alertTimerRef.current) clearTimeout(alertTimerRef.current);
            alertTimerRef.current = setTimeout(() => setNewLoginAlert(null), 5000);
          }
          prevPendingCountRef.current = count;

          // Only update state when something actually changed (avoids needless re-renders)
          setPendingCount((prev) => (prev === count ? prev : count));
          setPendingAgents((prev) => {
            const same =
              prev.length === agents.length &&
              prev.every((p, i) => p._id === agents[i]._id);
            return same ? prev : agents;
          });
          writePendingCache(count, agents);
        }
      } catch (err) {
        // silent fail
      } finally {
        inFlightRef.current = false;
      }
    };

    fetchPending();
    const interval = setInterval(fetchPending, 4000);
    return () => {
      cancelled = true;
      clearInterval(interval);
      if (alertTimerRef.current) clearTimeout(alertTimerRef.current);
    };
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setShowNotificationDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getInitials = (name) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  };

  const initials = getInitials(managerData.name);

  const handleLogout = () => {
    setIsLogoutModalOpen(true);
  };

  const confirmLogout = () => {
    setIsLogoutModalOpen(false);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    try {
      sessionStorage.removeItem(PENDING_CACHE_KEY);
    } catch (e) {
      // ignore
    }
    navigate('/');
  };

  const isItemActive = (item) => {
    const p = location.pathname.toLowerCase();
    return (
      p === item.path.toLowerCase() ||
      (item.isApproval && (p.includes('approval') || p.includes('aproval')))
    );
  };

  // KEY FIX: clicking the link of the page you're already on must NOT navigate again
  // (a same-path navigation creates a new location key and re-mounts/refreshes the page)
  const handleNavClick = (e, path, closeMobile = false) => {
    // Weekly Dues: run the RefreshButton refresh (clear cache + reload).
    // Other links are untouched.
    if (RELOAD_PATHS.includes(path.toLowerCase())) {
      e.preventDefault();
      if (closeMobile) setIsMobileMenuOpen(false);
      if (location.pathname.toLowerCase() !== path.toLowerCase()) {
        navigate(path);
      }
      // RefreshButton.js listens for this and runs its refresh function
      window.dispatchEvent(new Event('triggerAppRefresh'));
      return;
    }
    if (location.pathname.toLowerCase() === path.toLowerCase()) {
      e.preventDefault();
    }
    if (closeMobile) setIsMobileMenuOpen(false);
  };

  return (
    <>
      {/* Real-time Agent Login Toast Alert */}
      {newLoginAlert && (
        <div className="fixed top-18 right-6 z-50 bg-amber-500 text-gray-950 px-4 py-3 rounded-2xl shadow-2xl border-2 border-amber-300 font-bold text-xs flex items-center gap-3 animate-bounce">
          <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping"></span>
          <span>🔔 {newLoginAlert}</span>
          <Link
            to="/Manager/ManagerAproval"
            onClick={(e) => {
              handleNavClick(e, '/Manager/ManagerAproval');
              setNewLoginAlert(null);
            }}
            className="ml-2 bg-gray-900 text-white px-2.5 py-1 rounded-lg text-[10px] hover:bg-black transition"
          >
            Review Now
          </Link>
        </div>
      )}

      <nav className="sticky top-0 z-50 bg-emerald-900 text-white w-full shadow-md" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">

            <div className="flex items-center space-x-3">
              <img src="/karanLogo.jpeg" alt="Karan Finance" className="h-11 w-11 rounded-full object-cover" />
              <span className="text-2xl font-bold tracking-tight">Karan Finance</span>
            </div>

            {/* Desktop Nav Links */}
            <div className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => {
                const isActive = isItemActive(item);

                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={(e) => handleNavClick(e, item.path)}
                    className={`px-3 py-2 text-sm font-medium rounded-md transition-colors flex items-center gap-1.5 ${isActive
                      ? 'bg-emerald-700 text-white'
                      : 'hover:bg-emerald-800'
                      }`}
                  >
                    <span>{item.label}</span>
                    {item.isApproval && pendingCount > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-400 text-gray-950 animate-pulse">
                        {pendingCount}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>

            {/* User Info + Bell Notification + Logout (desktop) */}
            <div className="hidden md:flex items-center space-x-3">
              {/* Notification Bell with Dropdown */}
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={() => setShowNotificationDropdown(!showNotificationDropdown)}
                  className="relative p-2 rounded-full hover:bg-emerald-800 transition-colors text-white focus:outline-none"
                  title="Agent Approval Notifications"
                >
                  <BellIcon className="h-6 w-6" />
                  {pendingCount > 0 && (
                    <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-extrabold flex items-center justify-center animate-pulse">
                      {pendingCount}
                    </span>
                  )}
                </button>

                {/* Dropdown Menu */}
                {showNotificationDropdown && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden z-50 text-gray-800 animate-fadeIn">
                    <div className="bg-emerald-900 text-white p-3.5 flex items-center justify-between">
                      <span className="font-bold text-xs">Agent Login Alerts</span>
                      <span className="text-[11px] bg-amber-400 text-gray-950 font-extrabold px-2 py-0.5 rounded-full">
                        {pendingCount} Pending
                      </span>
                    </div>

                    <div className="max-h-64 overflow-y-auto divide-y divide-gray-100">
                      {pendingAgents.length === 0 ? (
                        <div className="p-4 text-center text-xs text-gray-500">
                          No pending agent login requests.
                        </div>
                      ) : (
                        pendingAgents.slice(0, 5).map((agent) => (
                          <Link
                            key={agent._id}
                            to="/Manager/ManagerAproval"
                            onClick={(e) => {
                              handleNavClick(e, '/Manager/ManagerAproval');
                              setShowNotificationDropdown(false);
                            }}
                            className="p-3 flex items-center justify-between hover:bg-emerald-50/60 transition block"
                          >
                            <div className="text-left">
                              <div className="font-bold text-xs text-gray-900">{agent.name || agent.username}</div>
                              <div className="text-[11px] text-gray-500">@{agent.username} • Waiting for approval</div>
                            </div>
                            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                              Review
                            </span>
                          </Link>
                        ))
                      )}
                    </div>

                    <div className="p-2 bg-gray-50 text-center border-t border-gray-100">
                      <Link
                        to="/Manager/ManagerAproval"
                        onClick={(e) => {
                          handleNavClick(e, '/Manager/ManagerAproval');
                          setShowNotificationDropdown(false);
                        }}
                        className="text-xs font-bold text-emerald-800 hover:underline block py-1"
                      >
                        Open Approval Management →
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* Manager User Info */}
              <div className="flex items-center space-x-2.5 p-1 rounded-xl">
                <div className="w-8 h-8 rounded-full bg-emerald-700 flex items-center justify-center font-bold text-sm shadow-sm overflow-hidden">
                  {managerData.profilePhoto ? (
                    <img src={managerData.profilePhoto} alt="profile" className="w-full h-full object-cover" />
                  ) : (
                    initials
                  )}
                </div>
                <div>
                  <div className="text-sm font-medium leading-tight">{managerData.name}</div>
                  <div className="text-xs text-emerald-200 leading-tight">{managerData.role}</div>
                </div>
              </div>

              {/* Logout button */}
              <button
                onClick={handleLogout}
                className="p-2 rounded-full hover:bg-emerald-800 transition-colors text-white"
                title="Logout"
              >
                <ArrowRightOnRectangleIcon className="h-5 w-5" />
              </button>
            </div>

            {/* Mobile Hamburger Button */}
            <div className="md:hidden flex items-center space-x-2">
              {pendingCount > 0 && (
                <Link
                  to="/Manager/ManagerAproval"
                  onClick={(e) => handleNavClick(e, '/Manager/ManagerAproval')}
                  className="p-1 text-amber-300 relative"
                  title="Pending Approvals"
                >
                  <BellIcon className="h-6 w-6" />
                  <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-red-500 rounded-full text-[9px] font-bold flex items-center justify-center text-white">
                    {pendingCount}
                  </span>
                </Link>
              )}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 rounded-md hover:bg-emerald-800 focus:outline-none"
              >
                {isMobileMenuOpen ? (
                  <XMarkIcon className="h-6 w-6" />
                ) : (
                  <Bars3Icon className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>

          {/* Logout Confirmation Modal */}
          {isLogoutModalOpen && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 px-4">
              <div className="bg-white rounded-2xl p-6 max-w-sm w-full text-center shadow-2xl text-gray-800">
                <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-100">
                  <svg className="h-8 w-8 text-emerald-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7" />
                  </svg>
                </div>
                <h4 className="text-xl font-bold text-gray-900">Sign Out</h4>
                <p className="text-gray-500 mt-2 mb-6">Are you sure you want to sign out, <span className="font-semibold text-emerald-700">{managerData.name}</span>?</p>
                <div className="flex gap-3">
                  <button onClick={() => setIsLogoutModalOpen(false)} className="flex-1 py-3.5 rounded-xl bg-gray-100 text-gray-700 font-bold hover:bg-gray-200 transition">Cancel</button>
                  <button onClick={confirmLogout} className="flex-1 py-3.5 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-700 shadow-xl transition">Logout</button>
                </div>
              </div>
            </div>
          )}

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden bg-emerald-800 py-4 px-2 space-y-2 border-t border-emerald-700" style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
              {navItems.map((item) => {
                const isActive = isItemActive(item);

                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={(e) => handleNavClick(e, item.path, true)}
                    className={`flex items-center justify-between px-4 py-3 rounded-md text-base font-medium ${isActive
                      ? 'bg-emerald-700 text-white'
                      : 'text-white hover:bg-emerald-700'
                      }`}
                  >
                    <span>{item.label}</span>
                    {item.isApproval && pendingCount > 0 && (
                      <span className="px-2 py-0.5 rounded-full text-xs font-black bg-amber-400 text-gray-900">
                        {pendingCount} Pending
                      </span>
                    )}
                  </Link>
                );
              })}

              <div className="px-4 py-3 border-t border-emerald-700 mt-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-700 flex items-center justify-center font-bold text-lg overflow-hidden">
                    {managerData.profilePhoto ? (
                      <img src={managerData.profilePhoto} alt="profile" className="w-full h-full object-cover" />
                    ) : (
                      initials
                    )}
                  </div>
                  <div>
                    <div className="text-sm font-medium">{managerData.name}</div>
                    <div className="text-xs text-emerald-300">{managerData.role}</div>
                  </div>
                </div>

                <button
                  onClick={handleLogout}
                  className="p-2 rounded-full hover:bg-emerald-700 text-white"
                >
                  <ArrowRightOnRectangleIcon className="h-5 w-5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>
    </>
  );
};

export default ManagerNavbar;